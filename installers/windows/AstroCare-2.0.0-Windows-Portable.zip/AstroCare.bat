@echo off
title AstroCare - Astronaut Health Monitoring System v2.0.0
cls
echo =====================================================================
echo    ASTROCARE - ASTRONAUT HEALTH MONITORING & RISK MANAGEMENT SYSTEM
echo    NASA Space Apps Challenge - Flight Telemetry Station v2.0.0
echo =====================================================================
echo.
echo Initializing local telemetry telemetry backend on http://127.0.0.1:8000 ...
cd /d "%~dp0app"
start "AstroCare Core Server" /min cmd /c "node backend\server.cjs"
timeout /t 2 /nobreak >nul
echo Launching AstroCare Mission Dashboard in browser...
start http://127.0.0.1:8000
echo.
echo =====================================================================
echo AstroCare is running.
echo To terminate the mission telemetry server, close this window or press Ctrl+C.
echo =====================================================================
pause
