@echo off
title AstroCare Desktop App
cls
cd /d "%~dp0app"
echo Launching AstroCare Native Desktop Client...
npx electron desktop\main.cjs
