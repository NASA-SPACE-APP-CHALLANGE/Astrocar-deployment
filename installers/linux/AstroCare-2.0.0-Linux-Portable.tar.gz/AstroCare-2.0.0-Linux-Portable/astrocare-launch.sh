#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export NODE_ENV=production
export DATA_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/astrocare/data"
mkdir -p "$DATA_DIR"

echo "=========================================================="
echo "  AstroCare — Astronaut Health Monitoring Platform"
echo "  Starting local telemetry core..."
echo "=========================================================="

# Start backend
node "$DIR/backend/server.cjs" &
BACKEND_PID=$!

cleanup() {
    echo "Stopping AstroCare..."
    kill $BACKEND_PID 2>/dev/null
    exit 0
}
trap cleanup INT TERM EXIT

sleep 1
URL="http://127.0.0.1:8000"
if which xdg-open >/dev/null 2>&1; then
    xdg-open "$URL"
elif which gnome-open >/dev/null 2>&1; then
    gnome-open "$URL"
else
    echo "Open $URL in your browser."
fi

wait $BACKEND_PID
